from djangopypi import settings
from djangopypi import signals
